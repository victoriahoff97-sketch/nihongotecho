/* Nihongo Techō – Erweiterung: Kärtchen an der Markierung (auf jeder Webseite, sobald sie Japanisch enthält) mit „Sätze erkennen“ und „Vokabel speichern“ */
'use strict';
(function () {
  if (globalThis.NTCard) return;
  globalThis.NTCard = true;
  const S = globalThis.NTSel;
  const VOCAB_MAX = 14;   // längere Markierungen sind kein einzelnes Wort mehr

  const host = document.createElement('div');
  host.style.cssText = 'position:absolute;z-index:2147483647;top:0;left:0;display:none';
  const root = host.attachShadow({ mode: 'open' });
  root.innerHTML = `<style>
    .card { display:flex; gap:6px; align-items:center; padding:6px; background:#fffdf9; color:#23262f; border:1px solid #e4ddd0; border-radius:12px;
      box-shadow:0 6px 20px rgba(35,38,47,.18); font:600 14px/1.2 system-ui,"Segoe UI",sans-serif; white-space:nowrap; }
    button { all:unset; box-sizing:border-box; min-height:40px; padding:0 14px; border-radius:8px; cursor:pointer; display:flex; align-items:center; gap:8px;
      background:#ece4f8; color:#4f3489; font:inherit; touch-action:manipulation; }
    button:hover, button:focus-visible { background:#6f4bb0; color:#fff; }
    .k { font-size:17px; font-weight:700; }
    .msg { padding:0 10px; max-width:260px; white-space:normal; font-weight:500; }
    [hidden] { display:none !important; }
  </style>
  <div class="card" part="card">
    <button data-ziel="saetze"><span class="k" lang="ja">例</span>Sätze erkennen</button>
    <button data-ziel="vokabel"><span class="k" lang="ja">単</span>Vokabel speichern</button>
    <span class="msg" hidden></span>
  </div>`;
  const card = root.querySelector('.card'), msg = root.querySelector('.msg');
  const btnVocab = root.querySelector('[data-ziel="vokabel"]'), btns = [...root.querySelectorAll('button')];

  const hide = () => { host.style.display = 'none'; };
  // In der App selbst kein Kärtchen: dort gibt es das Nachschlagen schon, und die Übergabe ginge an sich selbst
  const inApp = () => S.isAppTab({ title: document.title, url: location.href });
  const show = () => {
    const grab = inApp() ? null : globalThis.NTGrab();
    if (!grab) return hide();
    const range = getSelection().getRangeAt(0);
    const rects = range.getClientRects();
    const r = rects.length ? rects[rects.length - 1] : range.getBoundingClientRect();
    if (!r || (!r.width && !r.height)) return hide();
    msg.hidden = true; btns.forEach((b) => { b.hidden = false; });
    const word = S.plain(grab.text);
    btnVocab.hidden = word.length > VOCAB_MAX || /[\n。！？]/.test(word);
    if (!host.isConnected) document.body.appendChild(host);
    host.style.display = 'block';
    // unter dem Ende der Markierung, innerhalb des Fensters; Seitenkoordinaten, damit das Kärtchen beim Scrollen mitwandert
    const w = card.offsetWidth, vw = document.documentElement.clientWidth;
    const left = Math.max(8, Math.min(r.right - w / 2, vw - w - 8));
    host.style.left = (left + scrollX) + 'px';
    host.style.top = (r.bottom + scrollY + 10) + 'px';
  };

  let timer = 0;
  document.addEventListener('selectionchange', () => { clearTimeout(timer); timer = setTimeout(show, 200); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') hide(); });

  // Antippen des Kärtchens darf die Markierung nicht aufheben
  card.addEventListener('pointerdown', (e) => e.preventDefault());
  card.addEventListener('mousedown', (e) => e.preventDefault());
  card.addEventListener('click', async (e) => {
    const b = e.target.closest('button');
    const grab = b && globalThis.NTGrab();
    if (!grab) return;
    const ziel = b.dataset.ziel;
    let res;
    try { res = await chrome.runtime.sendMessage({ type: 'nt-send', ziel, text: grab.text, satz: ziel === 'vokabel' ? grab.satz : '' }); }
    catch (err) { res = { ok: false, grund: 'neu-laden' }; }
    if (res && res.ok) return hide();
    btns.forEach((x) => { x.hidden = true; });
    msg.hidden = false;
    msg.textContent = res && res.grund === 'keine-app' ? 'Nihongo Techō einmal öffnen, dann nochmal versuchen.'
      : res && res.grund === 'neu-laden' ? 'Erweiterung wurde aktualisiert – bitte diese Seite neu laden.'
        : 'Übergabe hat nicht geklappt. Ist Nihongo Techō geöffnet?';
  });
})();
