/* Nihongo Techō – Erweiterung: aktuelle Markierung der Seite lesen (mit Furigana aus <ruby>) */
'use strict';
(function () {
  const S = globalThis.NTSel;
  const SKIP = new Set(['RT', 'RP', 'SCRIPT', 'STYLE', 'NOSCRIPT', 'TEMPLATE']);
  const BLOCK = new Set(['P', 'DIV', 'LI', 'DT', 'DD', 'H1', 'H2', 'H3', 'H4', 'H5', 'H6', 'SECTION', 'ARTICLE', 'BLOCKQUOTE', 'TD', 'TH', 'FIGCAPTION', 'MAIN', 'BODY']);

  const textOf = (el, tag) => [...el.querySelectorAll(tag)].map((x) => x.textContent).join('');
  // Basis eines <ruby>: alles außer <rt>/<rp>
  const rubyBase = (el) => { const c = el.cloneNode(true); c.querySelectorAll('rt, rp').forEach((x) => x.remove()); return c.textContent; };

  // Text eines Textknotens, auf die Markierung beschnitten (ohne range: ganz)
  const clip = (n, range) => {
    if (!range) return n.nodeValue;
    if (!range.intersectsNode(n)) return '';
    const from = n === range.startContainer ? range.startOffset : 0;
    const to = n === range.endContainer ? range.endOffset : n.nodeValue.length;
    return n.nodeValue.slice(from, to);
  };
  // Markierter Teil eines <ruby>, getrennt nach Basis und Lesung
  const rubyParts = (el, range) => {
    let base = '', rt = '';
    const walk = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
    while (walk.nextNode()) {
      const n = walk.currentNode, up = n.parentElement.closest('rt, rp');
      if (up && up.tagName === 'RP') continue;
      if (up) rt += clip(n, range); else base += clip(n, range);
    }
    return { base, rt };
  };

  // Beginnt oder endet die Markierung in der Lesung (<rt>) dieses <ruby>?
  const inRt = (ruby, range) => [range.startContainer, range.endContainer].some((c) => {
    const rt = (c.nodeType === 1 ? c : c.parentElement).closest('rt');
    return !!rt && ruby.contains(rt);
  });

  // DOM → Token für NTSel.toNotation; mit range nur der markierte Teil.
  // Ein <ruby> bekommt seine Lesung nur, wenn die ganze Basis markiert ist (震 aus 地震 hat keine eigene Lesung).
  const tokens = (node, range, out = []) => {
    for (const n of node.childNodes) {
      if (range && !range.intersectsNode(n)) continue;
      if (n.nodeType === 3) { out.push({ s: clip(n, range) }); continue; }
      if (n.nodeType !== 1 || SKIP.has(n.tagName)) continue;
      if (n.tagName === 'RUBY') {
        const part = range ? rubyParts(n, range) : null;
        const full = { base: rubyBase(n), rt: textOf(n, 'rt') };
        out.push(part ? S.rubyToken({ base: full.base, rt: full.rt, selBase: part.base, selRt: part.rt, inRt: inRt(n, range) }) : full);
        continue;
      }
      if (n.tagName === 'BR') { out.push({ s: '\n' }); continue; }
      const block = BLOCK.has(n.tagName);
      if (block) out.push({ s: '\n' });
      tokens(n, range, out);
      if (block) out.push({ s: '\n' });
    }
    return out;
  };

  // Markierung innerhalb eines einzelnen <ruby> oder Textknotens: vom umgebenden Element aus lesen
  const rangeRoot = (range) => {
    let el = range.commonAncestorContainer;
    if (el.nodeType !== 1) el = el.parentElement;
    const ruby = el.closest('ruby');
    return ruby ? ruby.parentElement : el;
  };

  const blockOf = (node) => {
    let el = node.nodeType === 1 ? node : node.parentElement;
    while (el && !BLOCK.has(el.tagName)) el = el.parentElement;
    return el;
  };

  // → {text, satz} in der Furigana-Schreibweise der App; null ohne japanische Markierung
  globalThis.NTGrab = () => {
    const sel = globalThis.getSelection && getSelection();
    if (!sel || sel.isCollapsed || !sel.rangeCount) return null;
    const range = sel.getRangeAt(0);
    const text = S.toNotation(tokens(rangeRoot(range), range));
    if (!text || !S.isJp(text)) return null;
    const block = blockOf(range.commonAncestorContainer);
    // sehr große Blöcke (ganze Seite) taugen nicht als „Absatz“
    const para = block && block.textContent.length <= 3000 ? S.toNotation(tokens(block, null)) : '';
    return { text, satz: S.sentenceContaining(para, text) };
  };
})();
