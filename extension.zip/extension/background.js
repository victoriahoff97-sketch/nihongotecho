/* Nihongo Techō – Erweiterung, Hintergrund: Rechtsklick-Menü, App-Tab finden, Markierung übergeben */
'use strict';
// Chrome: der Service Worker lädt die Logik selbst; Firefox: die Hintergrundseite bekommt sie über „background.scripts“
if (typeof importScripts === 'function' && !globalThis.NTSel) importScripts('selection-logic.js');
const S = globalThis.NTSel;
// Firefox auf Android kennt weder Rechtsklick-Menü noch Fenster
const menus = chrome.contextMenus || null;

const MENU = { 'nt-saetze': ['saetze', 'Nihongo Techō: Sätze erkennen'], 'nt-vokabel': ['vokabel', 'Nihongo Techō: Vokabel speichern'] };

chrome.runtime.onInstalled.addListener(() => {
  if (!menus) return;
  menus.removeAll(() => {
    Object.entries(MENU).forEach(([id, [, title]]) => menus.create({ id, title, contexts: ['selection'] }));
  });
});

// ---------- App merken ----------
// Sobald ein App-Tab gesehen wird, seine Adresse merken – damit die App auch geöffnet werden kann, wenn kein Tab offen ist
const remember = (tab) => { if (S.isAppTab(tab)) chrome.storage.local.set({ appBase: S.appBase(tab.url) }); };
chrome.tabs.onUpdated.addListener((id, info, tab) => { if (info.title || info.status === 'complete') remember(tab); });
chrome.tabs.onActivated.addListener(({ tabId }) => { chrome.tabs.get(tabId, (tab) => { if (!chrome.runtime.lastError) remember(tab); }); });

const hint = (on) => {
  try {
    if (chrome.action.setBadgeText) chrome.action.setBadgeText({ text: on ? '!' : '' });
    chrome.action.setTitle({ title: on ? 'Nihongo Techō einmal öffnen, dann nochmal versuchen' : 'Nihongo Techō öffnen' });
  } catch (e) { /* ohne Hinweis am Symbol */ }
};
// App-Tab nach vorn holen (mit neuer Adresse); das Fenster nur dort, wo es Fenster gibt
const focus = async (tab, url) => {
  await chrome.tabs.update(tab.id, url ? { url, active: true } : { active: true });
  if (chrome.windows) await chrome.windows.update(tab.windowId, { focused: true });
};

// ---------- Übergabe ----------
// data: {ziel, text, satz}; from: Tab, aus dem die Markierung stammt (für Quelle und Fundstelle)
const send = async (data, from) => {
  let quelle = '', ref = '';
  try { const u = new URL(from.url); if (/^https?:$/.test(u.protocol)) { ref = u.href; quelle = S.quelleFor(u.hostname); } } catch (e) { /* ohne Fundstelle */ }
  const app = S.pickAppTab(await chrome.tabs.query({}));
  const base = app ? S.appBase(app.url) : S.fallbackBase((await chrome.storage.local.get('appBase')).appBase);
  const url = S.handoffUrl(base, { ziel: data.ziel, text: data.text, satz: data.satz, quelle, ref });
  try {
    if (app) await focus(app, url);
    else await chrome.tabs.create({ url });
  } catch (e) {
    console.warn('Nihongo Techō: Übergabe fehlgeschlagen', e);
    return { ok: false, grund: 'fehler', text: String(e && e.message || e) };
  }
  hint(false);
  return { ok: true };
};

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (!msg || msg.type !== 'nt-send' || !MENU['nt-' + msg.ziel]) return;
  send({ ziel: msg.ziel, text: String(msg.text || ''), satz: String(msg.satz || '') }, sender.tab || {}).then(reply);
  return true;   // Antwort kommt asynchron
});

if (menus) menus.onClicked.addListener(async (info, tab) => {
  const m = MENU[info.menuItemId];
  if (!m || !tab) return;
  // Markierung mit Furigana aus der Seite lesen; wo das nicht geht (PDF, geschützte Seiten), den einfachen Text nehmen
  let grab = null;
  try {
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['selection-logic.js', 'grab.js'] });
    const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => globalThis.NTGrab && globalThis.NTGrab() });
    grab = r && r.result;
  } catch (e) { /* Rückfall unten */ }
  const text = (grab && grab.text) || (info.selectionText || '').trim();
  if (!S.isJp(text)) return;
  send({ ziel: m[0], text, satz: m[0] === 'vokabel' ? ((grab && grab.satz) || '') : '' }, tab);
});

// Klick auf das Symbol: App nach vorn holen bzw. öffnen
chrome.action.onClicked.addListener(async () => {
  const app = S.pickAppTab(await chrome.tabs.query({}));
  if (app) return focus(app);
  const { appBase } = await chrome.storage.local.get('appBase');
  chrome.tabs.create({ url: S.fallbackBase(appBase) });
});
