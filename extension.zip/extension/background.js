/* Nihongo Techō – Erweiterung, Hintergrund: Rechtsklick-Menü, App-Tab finden, Markierung übergeben */
'use strict';
importScripts('selection-logic.js');
const S = globalThis.NTSel;

const MENU = { 'nt-saetze': ['saetze', 'Nihongo Techō: Sätze erkennen'], 'nt-vokabel': ['vokabel', 'Nihongo Techō: Vokabel speichern'] };

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => {
    Object.entries(MENU).forEach(([id, [, title]]) => chrome.contextMenus.create({ id, title, contexts: ['selection'] }));
  });
});

// ---------- App merken ----------
// Sobald ein App-Tab gesehen wird, seine Adresse merken – damit die App auch geöffnet werden kann, wenn kein Tab offen ist
const remember = (tab) => { if (S.isAppTab(tab)) chrome.storage.local.set({ appBase: S.appBase(tab.url) }); };
chrome.tabs.onUpdated.addListener((id, info, tab) => { if (info.title || info.status === 'complete') remember(tab); });
chrome.tabs.onActivated.addListener(({ tabId }) => { chrome.tabs.get(tabId, (tab) => { if (!chrome.runtime.lastError) remember(tab); }); });

const hint = (on) => {
  chrome.action.setBadgeText({ text: on ? '!' : '' });
  chrome.action.setTitle({ title: on ? 'Nihongo Techō einmal öffnen, dann nochmal versuchen' : 'Nihongo Techō öffnen' });
};

// ---------- Übergabe ----------
// data: {ziel, text, satz}; from: Tab, aus dem die Markierung stammt (für Quelle und Fundstelle)
const send = async (data, from) => {
  let quelle = '', ref = '';
  try { const u = new URL(from.url); if (/^https?:$/.test(u.protocol)) { ref = u.href; quelle = S.quelleFor(u.hostname); } } catch (e) { /* ohne Fundstelle */ }
  const app = S.pickAppTab(await chrome.tabs.query({}));
  const base = app ? S.appBase(app.url) : (await chrome.storage.local.get('appBase')).appBase;
  if (!base || !S.isAppUrl(base)) { hint(true); return { ok: false, grund: 'keine-app' }; }
  const url = S.handoffUrl(base, { ziel: data.ziel, text: data.text, satz: data.satz, quelle, ref });
  try {
    if (app) {
      await chrome.tabs.update(app.id, { url, active: true });
      await chrome.windows.update(app.windowId, { focused: true });
    } else await chrome.tabs.create({ url });
  } catch (e) {
    console.warn('Nihongo Techō: Übergabe fehlgeschlagen', e);
    return { ok: false, grund: 'fehler', text: String(e && e.message || e) };
  }
  hint(false);
  return { ok: true };
};

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (!msg || msg.type !== 'nt-send' || !MENU['nt-' + msg.ziel]) return;
  send({ ziel: msg.ziel, text: String(msg.text || ''), satz: String(msg.satz || '') }, sender.tab || {}).then(reply);
  return true;   // Antwort kommt asynchron
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  const m = MENU[info.menuItemId];
  if (!m || !tab) return;
  // Markierung mit Furigana aus der Seite lesen; wo das nicht geht (PDF, geschützte Seiten), den einfachen Text nehmen
  let grab = null;
  try {
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['selection-logic.js', 'grab.js'] });
    const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => globalThis.NTGrab && globalThis.NTGrab() });
    grab = r && r.result;
  } catch (e) { /* Rückfall unten */ }
  const text = (grab && grab.text) || (info.selectionText || '').trim();
  if (!S.isJp(text)) return;
  send({ ziel: m[0], text, satz: m[0] === 'vokabel' ? ((grab && grab.satz) || '') : '' }, tab);
});

// Klick auf das Symbol: App nach vorn holen bzw. öffnen
chrome.action.onClicked.addListener(async () => {
  const app = S.pickAppTab(await chrome.tabs.query({}));
  if (app) { await chrome.tabs.update(app.id, { active: true }); await chrome.windows.update(app.windowId, { focused: true }); return; }
  const { appBase } = await chrome.storage.local.get('appBase');
  if (appBase && S.isAppUrl(appBase)) chrome.tabs.create({ url: appBase });
});
