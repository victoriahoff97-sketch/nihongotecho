/* Nihongo Techō – Erweiterung: Markierung → Furigana-Schreibweise der App, Übergabe-Adresse, App-Tab finden.
   Nur Logik, kein DOM, keine chrome-API. Browser: globalThis.NTSel, Node: module.exports */
'use strict';
(function (root) {
  const KANJI = '\\u3400-\\u9fff\\uf900-\\ufaff々〆ヵヶ';
  const reOnlyKanji = new RegExp('^[' + KANJI + ']+$');
  const reKanjiEnd = new RegExp('[' + KANJI + ']$');
  const reFuri = new RegExp('\\{([^}]+)\\}\\[([^\\]]+)\\]|([' + KANJI + ']+)\\[([^\\]]+)\\]', 'g');
  const isJp = (s) => /[぀-ヿ㐀-鿿豈-﫿々]/.test(s || '');

  // Klammern aus dem Seitentext dürfen nicht als Schreibweise gelesen werden → Vollbreite
  const WIDE = { '[': '［', ']': '］', '{': '｛', '}': '｝' };
  const safe = (s) => String(s || '').replace(/[[\]{}]/g, (c) => WIDE[c]);

  // tokens: {s} Text · {s:'\n'} Absatzgrenze · {base, rt} Ruby
  const toNotation = (tokens) => {
    let out = '';
    for (const t of tokens || []) {
      if (t.base !== undefined || t.rt !== undefined) {
        const base = safe(t.base).replace(/\s+/g, ''), rt = safe(t.rt).replace(/\s+/g, '');
        if (!base) out += rt;
        else if (!rt) out += base;
        // Steht direkt davor ein Kanji ohne eigene Lesung, würde 大地震[じしん] die Lesung dem ganzen Wort zuschlagen → Klammerform
        else out += (reOnlyKanji.test(base) && !reKanjiEnd.test(out) ? base : '{' + base + '}') + '[' + rt + ']';
      } else if (t.s === '\n') out += '\n';
      else out += safe(t.s).replace(/\s+/g, '');
    }
    return out.replace(/\n{2,}/g, '\n').replace(/^\n+|\n+$/g, '');
  };

  // Token für ein <ruby>, von dem selBase/selRt markiert sind. Die Lesung gibt es nur zur ganzen Basis (震 aus 地震 hat keine
  // eigene); Furigana allein zählt nur, wenn die Markierung darin beginnt oder endet (inRt) – sonst liegt sie bloß im DOM dahinter.
  const rubyToken = ({ base, rt, selBase, selRt, inRt }) => {
    if (selBase && selBase === base) return { base, rt };
    if (selBase) return { s: selBase };
    return { s: inRt ? selRt : '' };
  };

  const plain = (notated) => String(notated || '').replace(reFuri, (m, g1, r1, k2) => g1 || k2);

  const splitSentences = (notated) => {
    const out = [];
    for (const line of String(notated || '').split('\n')) {
      for (const part of line.match(/[^。！？!?]+[。！？!?]*[」』）)]*/g) || []) if (part.trim()) out.push(part.trim());
    }
    return out;
  };

  // Der Satz des Absatzes, in dem die Markierung steht; sonst die Markierung selbst
  const sentenceContaining = (paragraph, selection) => {
    const needle = plain(selection).trim();
    if (!needle) return selection;
    return splitSentences(paragraph).find((s) => plain(s).includes(needle)) || selection;
  };

  const handoffUrl = (base, data) => {
    const q = new URLSearchParams();
    for (const k of ['ziel', 'text', 'satz', 'quelle', 'ref']) if (data[k]) q.set(k, data[k]);
    return base + '#/eingang?' + q.toString();
  };

  const appBase = (url) => String(url || '').split('#')[0];
  // Die App läuft aus dem Ordner, über den lokalen Server oder als Web-Version (GitHub Pages) – nur dorthin wird übergeben
  const isAppUrl = (url) => {
    let u;
    try { u = new URL(url); } catch (e) { return false; }
    if (u.protocol === 'file:') return true;
    if (u.protocol === 'http:') return u.hostname === 'localhost' || u.hostname === '127.0.0.1';
    return u.protocol === 'https:' && u.hostname.endsWith('.github.io');
  };
  const isAppTab = (tab) => !!tab && typeof tab.title === 'string' && tab.title.startsWith('Nihongo Techō') && isAppUrl(tab.url);
  const pickAppTab = (tabs) => (tabs || []).filter(isAppTab).sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0))[0] || null;

  // Nur NHK bekommt automatisch eine Quelle; auf allen anderen Seiten (auch WaniKani) wählt man sie in der App selbst
  const quelleFor = (hostname) => (/(^|\.)nhk\.or\.jp$|(^|\.)web\.nhk$/.test(hostname || '') ? 'NHK Easy' : '');

  const api = { isJp, toNotation, rubyToken, plain, splitSentences, sentenceContaining, handoffUrl, appBase, isAppUrl, isAppTab, pickAppTab, quelleFor };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.NTSel = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
